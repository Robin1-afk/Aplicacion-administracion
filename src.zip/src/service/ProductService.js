import axios from 'axios';

const ProductService = {
  getProducts: async () => {
    try {
      const response = await axios.get('http://127.0.0.1:8000/api/allNegocios');
      console.log("Response data:", response.data); // Verificar la respuesta
      return response.data;
    } catch (error) {
      console.error("Error fetching products:", error);
      return [];
    }
  }
};

export default ProductService;